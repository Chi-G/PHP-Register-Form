<?php
$dsn = 'mysql:host=localhost;dbname=admin-portal';
$db = new PDO($dsn, 'root', '');
?>