<?php
$smtphost = 'server2.tfhost.ng'; // SMTP Host Name
$smtpuser = 'chijindu.nwokeohuru@apslup.com'; // SMTP User Name
$smtppass = 'chibuike4u@tfhost'; // SMTP password
?>
