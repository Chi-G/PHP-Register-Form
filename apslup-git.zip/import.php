<?php

//import.php

if(!empty($_FILES['csv_file']['name']))
{
	//fopen function will open selected file & read file data stored under $file_data.

	//Get file name
	$file_data = fopen($_FILES['csv_file']['name'], 'r');

	fgetcsv($file_data); //passes csv fields which will be gotten from $file_data varieble
	while ($row = fgetcsv($file_data)) //fgetcsv here converts csv file data into php which will be accessed thru $file_data vsarieble using the while loop
	{
		// store csv file data into data varieble in array format 
		$data[] = array(
			'S/N' 				=> $row[0],
			'School' 	        => $row[1],
			'LGA' 				=> $row[2],
			'Enroll' 			=> $row[3],
			'Cooks'    	        => $row[4],
			'Phone No'       	=> $row[5],
            'Account No'       	=> $row[6]
		);
	}
	// lets send this data to ajax request in json format
	echo json_encode($data); //this will convert php array to json string & send to ajax request
}

?>